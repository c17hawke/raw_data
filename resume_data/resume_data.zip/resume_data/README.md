# Resume data

Source: https://www.kaggle.com/datasets/snehaanbhawal/resume-dataset
